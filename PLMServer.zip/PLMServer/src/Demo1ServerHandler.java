import PLMS.Messages.LoginMessage;
import org.apache.mina.core.service.IoHandlerAdapter;
import org.apache.mina.core.session.IoSession;
import org.apache.mina.core.session.IdleStatus;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;


/**
 * 服务器事件处理.
 */
public class Demo1ServerHandler extends IoHandlerAdapter{
    public static Logger log = LoggerFactory.getLogger(Demo1ServerHandler.class);

    @Override
    public void sessionCreated(IoSession session) throws Exception {
      //  log.info("创建新会话，服务端当前连接："+session.getService().getManagedSessionCount());

    }
    @Override
    public void sessionOpened(IoSession session) throws Exception {
        log.info("打开会话，服务端当前连接："+session.getService().getManagedSessionCount());
    }

    @Override
    public void messageReceived(IoSession session, Object message) throws Exception {
        String msg = message.toString();

        log.info("服务端接收到的数据为：" +((LoginMessage)message).length());
      //  log.info("服务端接收到的数据为：" +  (LoginMessage)message.toString());

    }

    @Override
    public void messageSent(IoSession session, Object message) throws Exception {
        //  logger.info("服务端发送信息成功...");
    }

    @Override
    public void sessionClosed(IoSession session) throws Exception {
        log.info("关闭会话，服务端当前连接："+session.getService().getManagedSessionCount());
    }

    @Override
    public void sessionIdle(IoSession session, IdleStatus status) throws Exception {
        log.info("服务端进入空闲状态...");
    }

    @Override
    public void exceptionCaught(IoSession session, Throwable cause) throws Exception {
        log.error("服务端异常...", cause);
    }

}
