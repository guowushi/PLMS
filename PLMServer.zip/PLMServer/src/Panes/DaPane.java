package Panes;

import com.jgoodies.forms.layout.CellConstraints;
import com.jgoodies.forms.layout.FormLayout;

import javax.swing.*;
import javax.swing.border.TitledBorder;
import java.awt.*;

/**
 * Created by IntelliJ IDEA.
 */
public class DaPane extends JPanel{
    private JButton button1;
    private JPanel panel1;
    private JButton button2;
    public DaPane() {
        //this.setLayout(new BorderLayout());
       // this.add(new Button("demo"),BorderLayout.NORTH);
        panel1 = new JPanel();
        panel1.setLayout(new FormLayout("fill:d:grow(0.4),left:4dlu:noGrow,fill:max(d;4px):grow(0.6)", "fill:102px:noGrow"));
        panel1.setBorder(BorderFactory.createTitledBorder(BorderFactory.createLoweredBevelBorder(), "ewew", TitledBorder.DEFAULT_JUSTIFICATION, TitledBorder.ABOVE_BOTTOM, new Font(panel1.getFont().getName(), panel1.getFont().getStyle(), panel1.getFont().getSize()), new Color(-16777216)));
        button1 = new JButton();
        button1.setText("Button");
        CellConstraints cc = new CellConstraints();
        panel1.add(button1, cc.xy(1, 1));
        button2 = new JButton();
        button2.setText("Button");
        panel1.add(button2, cc.xy(3, 1));
        this.add(panel1);
    }
}
