package server;

import PLMS.AreaJTree.AreaJTreeTalkId;
import PLMS.AreaJTree.TreeNode.MyTreeNode;
import PLMS.AreaJTree.UserDataForTreeNode.UserData;
import PLMS.Base.Module;
import PLMS.Base.WidgetBase;
import PLMS.DataUnits.AbstractFn;
import PLMS.talk.EventEx.ActionEventEx;
import Panes.GridPane;
import com.jidesoft.swing.JideComboBox;
import com.jidesoft.swing.JideTabbedPane;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.FocusAdapter;
import java.awt.event.FocusEvent;
import java.lang.reflect.Constructor;
import java.lang.reflect.InvocationTargetException;
import java.util.HashMap;
import java.util.Map;

/**
 * Created by IntelliJ IDEA.
 */
public class TabModule extends Module {
    private JideTabbedPane mainTab;
    private JPanel tab_setting;
    private JPanel tab_setting_settingPanel;
    private WidgetBase settingBase;
    private JPanel tab_others;
    private JPanel tab_default;
    private JPanel tab_addNode;
    public TabModule(){
        init();
        setLayout(new BorderLayout());
        add(mainTab);
    }
    
    protected void init() {
        mainTab =
        new JideTabbedPane();
        mainTab.setHideOneTab(false);
        mainTab.setSelectedTabFont(new Font(mainTab.getSelectedTabFont().getName(), Font.BOLD, mainTab.getSelectedTabFont().getSize()));
        mainTab.setShowCloseButton(false);
        mainTab.setTabPlacement(4);

        tab_default = new JPanel();
        tab_default.setLayout(new BorderLayout(0, 0));
        GridPane grid = new GridPane();
        tab_default.setLayout(new BorderLayout());
        tab_default.add(grid, "Center");

        tab_setting = new JPanel();
        tab_setting.setLayout(new FlowLayout(FlowLayout.CENTER, 5, 5));
        tab_setting.setLayout(new BorderLayout());
        tab_setting_settingPanel=new JPanel();
        tab_setting.add(tab_setting_settingPanel,BorderLayout.CENTER);


        JPanel btnPanel = new JPanel();
        btnPanel.setLayout(new FlowLayout());
        tab_setting.add(btnPanel, BorderLayout.SOUTH);
        JButton okbtn = new JButton("确定");
        btnPanel.add(okbtn);
        okbtn.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
               //TODO 提交
                settingBase.getValue();
            }
        });
        JButton btn_test = new JButton("测试");
        btnPanel.add(btn_test);
        btn_test.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
            }
        });

        tab_others = new JPanel();
        tab_others.setLayout(new FlowLayout(FlowLayout.CENTER, 5, 5));


        mainTab.addTab("系统状态", tab_default);

        mainTab.addTab("参数设置", tab_setting);

        mainTab.addTab("其他", tab_others);
    }
    ActionListener alForAddNode=new ActionListener(){
        boolean lock=false;
        @Override
        public void actionPerformed(ActionEvent e) {
            ActionEventEx ex=(ActionEventEx)e;
            try{
                 MyTreeNode node=(MyTreeNode)e.getSource();
                 UserData ud=(UserData)node.getUserObject();
                if(lock){
                    JOptionPane.showConfirmDialog(mainTab, "你确定要放弃当前正在进行的编辑吗？", "添加", JOptionPane.YES_NO_OPTION);
                }

                if(tab_addNode==null){
                    tab_addNode=new JPanel(new BorderLayout());
                    JButton btnOk=new JButton("确定");
                    JButton btnCancel=new JButton("取消");
                    JPanel group=new JPanel();
                    DefaultTableModel tm=new DefaultTableModel(new String[]{"名称"},1);
                    JTable table=new JTable(tm);
                    group.add(btnOk);
                    group.add(btnCancel);
                    tab_addNode.add(new JScrollPane(table),BorderLayout.CENTER);
                    tab_addNode.add(group,BorderLayout.SOUTH);
                 
                    mainTab.addTab("添加", tab_addNode);
                    mainTab.setSelectedComponent(tab_addNode);
                    mainTab.updateUI();
                }
                switch (ex.getTalkId()){
                    case AreaJTreeTalkId.ADD_AREA:break;
                    case AreaJTreeTalkId.ADD_POWERSUBSTATION:break;
                    case AreaJTreeTalkId.ADD_COLLECTION_POINT:break;
                    case AreaJTreeTalkId.ADD_LINE:break;
                    case AreaJTreeTalkId.ADD_TERMINAL:break;
                }

            }catch (ClassCastException ex1){

            }

            //To change body of implemented methods use File | Settings | File Templates.
        }
    };
    ActionListener alforSettingMenuItem=new ActionListener() {
        @Override
        public void actionPerformed(ActionEvent e) {
            ActionEventEx ex=(ActionEventEx)e;
            String []settingPanel=map.get(new Integer(ex.getTalkId()));
            if(settingPanel!=null){
                Class panel=null;
                Class fn=null;
                try {
                    panel=Class.forName(settingPanel[0]);
                    fn=Class.forName(settingPanel[1]) ;
                } catch (ClassNotFoundException e1) {
                    e1.printStackTrace();
                }
                AbstractFn fnData;
                try {
                    fnData=(AbstractFn)fn.newInstance();
                    Constructor constructor= panel.getConstructor(fnData.getClass()) ;
                    settingBase=(WidgetBase)constructor.newInstance(fnData);
                    mainTab.setSelectedComponent(tab_setting);
                    tab_setting_settingPanel.removeAll();
                    tab_setting_settingPanel.setLayout(new BorderLayout());
                    tab_setting_settingPanel.add(settingBase.getContentPane(),BorderLayout.CENTER);
                    tab_setting_settingPanel.updateUI();
                } catch (InstantiationException e1) {
                    e1.printStackTrace();
                } catch (IllegalAccessException e1) {
                    e1.printStackTrace();
                }
                catch (NoSuchMethodException e1) {
                    e1.printStackTrace();
                } catch (InvocationTargetException e1) {
                    e1.printStackTrace();
                }
            }
        }
    };
    

    HashMap<Integer, String[]> map=new HashMap<Integer, String[]>();
    {
        map.put(new Integer(AreaJTreeTalkId.MENU_TERMINAL_COMMUNICATION),new String[]{"Panes.setting_F1","PLMS.DataUnits.AFN04.F1"});
        map.put(new Integer(AreaJTreeTalkId.MENU_IP_PORT),new String[]{"Panes.setting_F3","PLMS.DataUnits.AFN04.F3"});
        map.put(new Integer(AreaJTreeTalkId.MENU_PHONE_SMS),new String[]{"Panes.setting_F4","PLMS.DataUnits.AFN04.F4"});
        map.put(new Integer(AreaJTreeTalkId.MENU_MSG_AUTH_PARAM),new String[]{"Panes.setting_F5","PLMS.DataUnits.AFN04.F4"});
    }
     
}

