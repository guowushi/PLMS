package server;

import PLMS.codec.MessagesProtocolCodecFactory;
import handlers.ServerHandlerTransponder;
import org.apache.mina.core.service.IoAcceptor;
import org.apache.mina.core.session.IdleStatus;
import org.apache.mina.filter.codec.ProtocolCodecFilter;
import org.apache.mina.filter.logging.LoggingFilter;
import org.apache.mina.transport.socket.nio.NioSocketAcceptor;

import java.net.InetSocketAddress;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import org.apache.commons.configuration.ConfigurationException;
import org.apache.commons.configuration.XMLConfiguration;

/**
 * 服务器 主线程程序
 */
public class Server  {
    private int PORT = 3005;
    private String IP="0.0.0.0";
    public static Logger log = LoggerFactory.getLogger(Server.class);
    private static IoAcceptor acceptor = null;
    private Server(){};
    private static Server server=new Server();
    public int status;
    public static Server getInstance(){
        return server;
    }
    public static void main(String[] args) {
        // new server.Server().start();
     }
    public IoAcceptor getIoAcceptor()
    {

        return acceptor;
    }

    /**
     * 载入服务器的配置文件
     */
    public void loadConf()  {
        try {
            XMLConfiguration conf=new XMLConfiguration("funcs.xml") ;
            IP=conf.getString("server.ip",IP);
            PORT= conf.getInt("server.port",PORT);
            //System.out.print(PORT);
        } catch (ConfigurationException e) {
             System.out.println("读取配置文件(func.xml)失败！");
        }

    }

    /**
     * 服务器端初始化（只进行一次）
     */
    public void init()
    {
        loadConf();
        try {
            // ---------------------创建TCP Socket -----------------------------------------
            acceptor = new NioSocketAcceptor();
            // ---------------------设置Filter----------------------------------------------
            acceptor.getFilterChain().addLast("logger", new LoggingFilter());
            //MyCoderFactory mf=new MyCoderFactory();
            MessagesProtocolCodecFactory mf = new MessagesProtocolCodecFactory(true);
            ProtocolCodecFilter fl = new ProtocolCodecFilter(mf);
            acceptor.getFilterChain().addLast("PLMS/codec", fl);
            // ----------------------服务器端参数设置------------------------------------------
            //acceptor.getSessionConfig().setReadBufferSize(20);// 设置读缓冲
            // 设置如果10秒后没有上下数据传输，触发
            acceptor.getSessionConfig().setIdleTime(IdleStatus.BOTH_IDLE, 10);
            // -----------------------服务器事件处理--------------------------------------------
            ServerHandlerTransponder ht = new ServerHandlerTransponder();
            acceptor.setHandler(ht);

            log.info("服务器初始化成功！" );
            status=1;
        } catch (Exception e) {
            log.error("服务器初始化异常...");
            e.printStackTrace();
        }
    }
    public void start() {
        try {
            // ------------------------绑定IP和端口 ---------------------------------------------
            acceptor.bind(new InetSocketAddress(IP,PORT));
            log.info("服务器端口监听成功！" +IP+":"+PORT );
            status=2;
        } catch (Exception e) {
            log.error("服务器端口监听异常...");
            e.printStackTrace();
        }
    }

    /**
     * 服务器端暂时停止服务
     */
    public void pause()
    {
        acceptor.unbind();
    }
    public void resume()
    {
        this.start();
    }

    /**
     * 关闭服务器
     */
    public void stop()
    {
        acceptor.unbind();
        log.info("服务器停止！" );
        if(acceptor.isDisposed()!=true)
        {
          //  acceptor.dispose();
        }
    }
    public final static int CUSTOM_RECV=0;
}
