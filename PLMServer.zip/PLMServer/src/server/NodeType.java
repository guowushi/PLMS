package server;

/**
 * Created by IntelliJ IDEA.
*/
public enum NodeType {
    LOGINED,
    ALIVE,
    TERMINAL;
  }
