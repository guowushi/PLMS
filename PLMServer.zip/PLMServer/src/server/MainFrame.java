package server;

import PLMS.AreaJTree.CellRenderer;
import PLMS.AreaJTree.TerminalNodeManager;
import PLMS.AreaJTree.UserDataForTreeNode.ForRoot;
import PLMS.AreaJTree.UserDataForTreeNode.ForTerminal;
import PLMS.AreaJTree.UserDataForTreeNode.UserData;
import PLMS.Base.Module;
import PLMS.DataUnits.AFN04.F1;
import PLMS.GUI.LoginDialog;
import PLMS.GUI.LoginWindow;
import PLMS.GUI.MainStationFrame;
import PLMS.GUI.PLMSJFrame;
import PLMS.talk.LoudSpeaker;
import Panes.*;
import com.jidesoft.swing.CheckBoxTree;
import com.jidesoft.swing.CheckBoxTreeSelectionModel;
import com.jidesoft.swing.JideScrollPane;
import com.jidesoft.swing.JideTabbedPane;
import org.apache.commons.configuration.ConfigurationException;
import org.apache.commons.configuration.HierarchicalConfiguration;
import org.apache.commons.configuration.XMLConfiguration;
import org.apache.mina.core.session.IoSession;

import java.awt.event.*;
import java.net.InetSocketAddress;
import java.sql.*;
import java.util.ArrayList;
import java.util.Enumeration;
import java.util.List;
import javax.swing.*;
import javax.swing.event.TreeModelEvent;
import javax.swing.event.TreeModelListener;
import javax.swing.event.TreeSelectionEvent;
import javax.swing.event.TreeSelectionListener;
import javax.swing.tree.DefaultMutableTreeNode;
import javax.swing.tree.TreeNode;
import javax.swing.tree.TreePath;
import javax.swing.tree.TreeSelectionModel;

import java.awt.*;
import java.util.Map;

/**
 * 主站程序
 */
public class MainFrame {



    public MainFrame(){

        long  t1=System.currentTimeMillis();
        //startProgess.setText("Load tree...");
        StartProgess.startProgess.plus();
        treeModule = new TreeModule();
        StartProgess.startProgess.plus();
        tabModule=new TabModule();
        StartProgess.startProgess.plus();
        split_main = new JSplitPane();
        StartProgess.startProgess.plus();
        split_main.setOrientation(1);
        StartProgess.startProgess.plus();
        split_main.setBorder(BorderFactory.createTitledBorder(BorderFactory.createLoweredBevelBorder(), null));
        StartProgess.startProgess.plus();
        split_main_right = new JSplitPane();
        StartProgess.startProgess.plus();
        split_main_right.setOrientation(0);
        StartProgess.startProgess.plus();
        split_main.setRightComponent(split_main_right);
        StartProgess.startProgess.plus();
        statusScroll = new JideScrollPane();
        StartProgess.startProgess.plus();
        statusScroll.setHorizontalScrollBarPolicy(30);
        StartProgess.startProgess.plus();
        statusScroll.setVerticalScrollBarPolicy(22);
        StartProgess.startProgess.plus();
        split_main_right.setRightComponent(statusScroll);
        StartProgess.startProgess.plus();
        mainScollPane = new JideScrollPane();
        StartProgess.startProgess.plus();
        split_main_right.setLeftComponent(mainScollPane);
        StartProgess.startProgess.plus();
        mainScollPane.setViewportView(tabModule);
        StartProgess.startProgess.plus();
        split_main.setLeftComponent(new JideScrollPane(treeModule));
        StartProgess.startProgess.plus();

    }
    
    
    
    private TreeModule treeModule; //树模块
    private TabModule tabModule;//tab 模块

    private JSplitPane split_main;
    private JSplitPane split_main_right;
    private JideScrollPane statusScroll;
    private JideScrollPane mainScollPane;



    // ---------------------------------------
    private MainStationFrame frame;
    private Server server;


    private void createUIComponents() {

        // ------------ 主窗体对象 --------------------
        LoginDialog login = new LoginDialog(null, true, "");
        login.setVisible(true);

        if (login.getAnswer() == true) {
        long t1=System.currentTimeMillis();
            frame = new MainStationFrame("电力管理系统", 1,1);


            login.setVisible(false);
            frame.setContentPane(split_main);
            frame.setSize(800, 600);
            frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
            //--------------主窗体事件处理--------------------
            //frame.addWindowListener(new close());
            frame.getMenuItemByName("系统.退出").addActionListener(new exitHandler());
            frame.getMenuItemByName("系统.启动服务").addActionListener(new startHandler());
            frame.getMenuItemByName("系统.停止服务").addActionListener(new stopHandler());

            statusScroll.setMinimumSize(new Dimension(50, 50));
            mainScollPane.setMinimumSize(new Dimension(100, 400));
            talk();
            frame.setVisible(true);
        System.out.println("启动："+(System.currentTimeMillis()-t1));
        }


    }

    private void talk(){
       LoudSpeaker loudSpeaker= Module.getLoudSpeaker();
      loudSpeaker.registerActionListener(treeModule,tabModule.alforSettingMenuItem);  //tabModule 需要响应treeModule弹出菜单的事件
       loudSpeaker.registerActionListener(treeModule,tabModule.alForAddNode);//tabModule响应treeModule的添加XX菜单
    }


    public static void main(String[] args) {
        try{
            for(UIManager.LookAndFeelInfo info :UIManager.getInstalledLookAndFeels()) {
                if("Windows".equals(info.getName()))   {
                    UIManager.setLookAndFeel(info.getClassName() );
                    break;
                }
            }
            //   jb.updateUI();
            //  jc.updateUI();

        }catch (Exception e1){
            System.out.println(e1.getMessage());
        }
         StartProgess.startProgess.setMaxValue(16);StartProgess.startProgess.setVisible(false);
        StartProgess.startProgess.setText("init...");
        long t1=System.currentTimeMillis();
       MainFrame m = new MainFrame();
        System.out.println("实例化:"+(System.currentTimeMillis()-t1));

        m.createUIComponents();

    }



    public JComponent $$$getRootComponent$$$() {
        return split_main;
    }



    // ----------------------------------菜单事件------------------------------------------------------------------


    // ------------------------------菜单事件-------------------------------------------

    private class exitHandler implements ActionListener {
        @Override
        public void actionPerformed(ActionEvent e) {
            System.exit(0);
        }
    }

    private class startHandler implements ActionListener {
        @Override
        public void actionPerformed(ActionEvent e) {
            if (server == null) {
                server = Server.getInstance();
                server.init();
                Map<Long, IoSession> sessionMap = server.getIoAcceptor().getManagedSessions();
            }
            if (server.getIoAcceptor().isActive() == false) {
                server.start();
                JMenuItem currentMnItem = (JMenuItem) e.getSource();
                currentMnItem.setEnabled(false);
                frame.getJMenuBar().getMenu(0).getItem(1).setEnabled(true);

            }

        }
    }


    private class stopHandler implements ActionListener {
        @Override
        public void actionPerformed(ActionEvent e) {

            if (server.getIoAcceptor().isActive()) {
                server.stop();
                JMenuItem currentMnItem = (JMenuItem) e.getSource();
                currentMnItem.setEnabled(false);
                frame.getJMenuBar().getMenu(0).getItem(0).setEnabled(true);

            }
        }
    }

    private class terminalSettingHandler implements ActionListener {
        @Override
        public void actionPerformed(ActionEvent e) {
            System.exit(0);
        }
    }

    public void showLog() {
        Map<Long, IoSession> sessionMap = server.getIoAcceptor().getManagedSessions();
        for (IoSession s : sessionMap.values()) {
            System.out.println("会话ID:" + s.getId());
            System.out.println("     会话读取消息数：" + s.getReadMessages());
            System.out.println("     会话发送消息数：" + s.getWrittenMessages());
            System.out.println("     客户端地址：" + ((InetSocketAddress) s.getRemoteAddress()).getAddress().toString());

        }
    }
}

// -------------------------------------------------------------------------------------------------------------


